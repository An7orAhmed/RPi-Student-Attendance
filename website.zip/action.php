<?php
include 'config/init.php';
include 'lib/inputProcess.php';
$db = new Database();

if (isset($_GET['list'])) {
    $db->query('SELECT * FROM `students`');
    $students = $db->fetchAll();
    echo json_encode($students);
}

if (isset($_GET['settings'])) {
    $db->query('SELECT * FROM `configuration`');
    $students = $db->fetchAll();
    echo json_encode($students);
}

if (isset($_GET['arrive'])) {
    $id = $_GET['id'];
    $date = $_GET['date'];
    $time = $_GET['time'];
    $remarks = $_GET['remarks'];
    
    $sql = "UPDATE `attendance` SET `arrival_time`='$time', `remarks`='$remarks' WHERE `date`='$date' AND `id`='$id'";
    $db->query($sql);
    $db->execute();
}

if (isset($_GET['get'])) {
    $id = $_GET['id'];
    $date = $_GET['date'];
    
    $sql = "SELECT * FROM `attendance` WHERE `date`='$date' AND `id`='$id'";
    $db->query($sql);
    $students = $db->fetchAll();
    echo json_encode($students);
}
?>