<?php
//Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'esinebdc_projects');
define('DB_PASS', 'QyO2P7h{e;DBW)o!7)Of');
define('DB_NAME', 'esinebdc_attendance');

#Site Configuration
define('SITE_TITLE', 'RPi Attendance System');
define('SITE_CODE', 'RPi Attendance System');