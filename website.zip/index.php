<?php
ob_start();
session_start();
include 'config/init.php';
include 'lib/inputProcess.php';
$db = new Database();
?>


<?php
if (!isset($_SESSION['user'])) {
	header('location: login.php');
} else {
	extract($_SESSION['user']);
}
?>

<?php
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (isset($_GET['switchtoggle'])) {
	$id = input_filter($_GET['switchtoggle']);
	$db->query('UPDATE `switchview` SET `value`= !value WHERE `serial`= ?');
	$db->execute([$id]);
	header('location: index.php');
}

$selectedDate = (new DateTime())->format('Y-m-d');
$stime = (new DateTime())->format('H:i');
$etime = (new DateTime())->format('H:i');

if (isset($_GET['date'])) {
    $selectedDate = input_filter($_GET['date']);
    $db->query("UPDATE `configuration` SET `value`='$selectedDate' WHERE `item`='date'");
	$db->execute();
	
	$db->query('SELECT * FROM `students`');
    $students = $db->fetchAll();
    
    foreach ($students as $key => $student) {
        $date = (new DateTime($selectedDate))->format('j-M-y');
        $name = $student->name;
        $id = $student->fingerId;
    	$sql = "INSERT INTO `attendance`(`date`, `id`, `name`, `arrival_time`, `remarks`) ";
        $sql = $sql . "SELECT '$date','$id','$name','','' WHERE NOT EXISTS (SELECT 1 from `attendance` WHERE `date`='$date' AND `id`='$id')";
        $db->query($sql);
	    $db->execute();
    }
}

if (isset($_GET['stime'])) {
    $stime = input_filter($_GET['stime']);
    if($stime != '') {
        $db->query("UPDATE `configuration` SET `value`='$stime' WHERE `item`='stime'");
	    $db->execute();
	    header('location: index.php');
    }
}

if (isset($_GET['etime'])) {
    $etime = input_filter($_GET['etime']);
    if($etime != '') {
        $db->query("UPDATE `configuration` SET `value`='$etime' WHERE `item`='etime'");
    	$db->execute();
    	header('location: index.php');
    }
}

if (isset($_GET['sms'])) {
    $sms = input_filter($_GET['sms']);
    if($sms != '') {
        $db->query("UPDATE `configuration` SET `value`='$sms' WHERE `item`='sms'");
    	$db->execute();
    	header('location: index.php');
    }
}

$sql = "SELECT * FROM `configuration`";
$result = $mysqli -> query($sql);
while ($row = $result -> fetch_assoc()) {
    if($row["item"] == "date") {
        $selectedDate = $row["value"];
        $selectedDate = (new DateTime($selectedDate))->format('Y-m-d');
    }
    if($row["item"] == "stime") $stime = $row["value"];
    if($row["item"] == "etime") $etime = $row["value"];
    if($row["item"] == "sms") $sms = $row["value"];
}
?>


<?php
$header = new Templete('common/header');
$footer = new Templete('common/footer');
?>

<?php echo $header ?>

<div class="container">
	<div class="view sensors-view">
	  <span class="title"><i class="fas fa-tachometer-alt"></i> XYZ University : Attendance Sheet</span><br><br>
	  <div>
	      <form method="GET" action="<?php echo $_SERVER["PHP_SELF"];?>">
	          <label for="stime">Class Start Time: </label>
    	      <input type="time" id="stime" name="stime" value="<?php echo $stime; ?>" class="mx-2">
    	      <label for="etime">Class End Time: </label>
    	      <input type="time" id="etime" name="etime" value="<?php echo $etime; ?>" class="mx-2">
    	      <label for="date">Attendance Date: </label>
    	      <input type="date" id="date" name="date" value="<?php echo $selectedDate; ?>" class="mx-2">
    	      <input type="radio" id="smsOn" name="sms" value="1" <?php if($sms == "1") echo 'checked';?>>
    	      <label for="smsOn" class="mr-2">SMS ON </label>
    	      <input type="radio" id="smsOff" name="sms" value="0" <?php if($sms == "0") echo 'checked';?>>
    	      <label for="smsOff" class="mr-2">SMS OFF</label>
              <input type="submit" value="UPDATE" class="btn btn-success px-4">
	      </form>
	  </div>
	  <hr>
      <div style="height: 400px; position: relative; overflow: auto;">
         <table class="table table-bordered table-striped mb-0">
            <tr>
               <th>Student ID</th>
               <th>Name</th>
               <th>Arrival Time</th>
               <th>Remarks</th>
            </tr>
            <?php
                $date = (new DateTime($selectedDate))->format('j-M-y');
                $sql = "SELECT * FROM `attendance` WHERE date='$date'";
                $result = $mysqli -> query($sql);
                 while ($row = $result -> fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["arrival_time"] . "</td>";
                    echo "<td>" . $row["remarks"] . "</td>";
                    echo "</tr>";
                }
                $result -> free_result();
                $mysqli -> close();
            ?>
         </table>
      </div>
	</div>
</div>

<?php if ($usertype == 'admin') :  ?>
	<a href="customize-admin.php#userview" class="add-user btn btn-light">
		<i class="fas fa-user-plus"></i>
	</a>
<?php endif; ?>

<?php echo $footer ?>