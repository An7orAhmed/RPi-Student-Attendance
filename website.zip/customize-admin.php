<?php
session_start();
include 'config/init.php';
include 'lib/inputProcess.php';
$db = new Database();
?>


<?php
if (!isset($_SESSION['user'])) {
	header('location: login.php');
} else {
	extract($_SESSION['user']);
	if ($usertype != 'admin') {
		header('location: unauthorized.php');
	}
}
?>

<?php
function goBackError($e)
{
	header('location: customize-admin.php?e=' . $e);
}

/*====================================
	=            Form Control            =
	====================================*/

/*----------  Switch Add  ----------*/


if (isset($_POST['name'])) {
	$name = input_filter($_POST['name']);
	$fingerId = input_filter($_POST['fingerId']);
	$phone = input_filter($_POST['phone']);
	//print_r($_FILES);

	$db->query('INSERT INTO `students`(`name`, `fingerId`, `phone`) VALUES (:col_1,:col_2,:col_3)');
	$db->execute([
		'col_1' => $name,
		'col_2' => $fingerId,
		'col_3' => $phone
	]);
}


/*----------  Add User  ----------*/

if (isset($_POST['username'])) {
	$username = input_filter($_POST['username']);
	$password = input_filter($_POST['password']);

	$db->query('INSERT INTO `user`(`username`, `password`, `usertype`) VALUES (:col_1,:col_2,:col_3)');
	$db->execute([
		'col_1' => $username,
		'col_2' => $password,
		'col_3' => 'user'
	]);
}

/*=====  End of Form Control  ======*/



/*=============================================
	=            remove button control            =
	=============================================*/

if (isset($_GET['remove'])) {
	$what = input_filter($_GET['remove']);
	$id = input_filter($_GET['id']);
	if ($what == 'sensor') {
		$db->query('DELETE FROM `sensorview` WHERE `serial`=?');
		$db->execute([$id]);
	} else if ($what == 'switch') {
		$db->query('DELETE FROM `students` WHERE `serial`=?');
		$db->execute([$id]);
	} else if ($what == 'user') {
		$db->query('DELETE FROM `user` WHERE `id`=?');
		$db->execute([$id]);
	}
}


/*=====  End of remove button control  ======*/
?>

<?php if (isset($_GET['e'])) : ?>
	<script>
		alert('<?php echo $_GET['e']; ?>');
	</script>
<?php endif ?>

<?php
$header = new Templete('common/header');
$footer = new Templete('common/footer');
?>

<?php echo $header; ?>
<div class="container pt-2">
	<section id="switchview">
		<div class="view">
			<div class="title">
				Add New Student/Teacher
			</div>
			<hr>
			<form action="<?php echo $_SERVER['PHP_SELF'] . '?'; ?>" method="POST" enctype="multipart/form-data">
				<div class="row">
					<div class="col-sm-3">
						<input name="name" type="text" class="form-control" placeholder="Enter Student/Teacher Name">
					</div>

					<div class="col-sm-3">
						<input name="fingerId" type="text" class="form-control" placeholder="Enrolled Finger ID">
					</div>
					
					<div class="col-sm-3">
						<input name="phone" type="text" class="form-control" placeholder="Phone No.">
					</div>
				</div>
				<br>
				<button class="form-control btn-success" type="submit" value="submit">Add to List</button>
			</form>
			<hr>
			<?php
			$db->query('SELECT * FROM `students`');
			$switches = $db->fetchAll();
			//print_r($switches);
			?>
			<div class="h5 text-center">Students/Teachers</div>
			<table class="table table-hover table-light text-center">
				<tbody>
					<?php foreach ($switches as $key => $switch) : ?>
						<tr>
							<th scope="row"><?php echo $switch->name ?></th>
							<td><?php echo $switch->fingerId ?></td>
							<td class="text-right"><a href="<?php echo $_SERVER['PHP_SELF'] . '?remove=switch&id=' . $switch->serial ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
						</tr>
					<?php endforeach ?>
			</table>
		</div>
	</section>

	<section id="userview">
		<div class="view">
			<div class="title">
				User settings
			</div>
			<hr>
			<form action="<?php echo $_SERVER['PHP_SELF'] . '?'; ?>" method="POST">
				<div class="row">
					<div class="col-sm-4">
						<input name="username" type="text" class="form-control" placeholder="username">
					</div>
					<div class="col-sm-4">
						<input name="password" type="text" class="form-control" placeholder="password">
					</div>
					<br>
					<button class="m-3 form-control btn-success" type="submit" value="submit">Add User</button>
				</div>
			</form>
			<hr>

			<?php
			$db->query('SELECT * FROM `user` WHERE `usertype` = "user" ');
			$users = $db->fetchAll();
			//print_r($users);
			?>
			<div class="h5 text-center">users</div>
			<table class="table table-hover table-light text-center">
				<tbody>
					<?php foreach ($users as $key => $user) : ?>
						<tr>
							<th scope="row"><?php echo $user->username ?></th>
							<td class="text-right"><a href="<?php echo $_SERVER['PHP_SELF'] . '?remove=user&id=' . $user->id ?>" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
						</tr>
					<?php endforeach ?>
			</table>
		</div>
</div>
</section>
<a href="index.php" class="add-user btn btn-light">
	<i class="fas fa-door-closed"></i>
</a>
<?php echo $footer; ?>